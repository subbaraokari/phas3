package org.simplilearn.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.simplilearn.demo.entities.Course;
import org.simplilearn.demo.entities.Instructor;
import org.simplilearn.demo.entities.Instructor_Detail;
import org.simplilearn.demo.repositories.InstructorRepository;
import org.simplilearn.demo.repositories.Instructor_Detail_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MyRunner implements CommandLineRunner{
	@Autowired
	private InstructorRepository instructorRepository;
	@Autowired
	private Instructor_Detail_Repository instructor_Detail_Repository;
	@Transactional
	@Override
	public void run(String... args) throws Exception {
		/*Instructor_Detail instructor_Detail=new Instructor_Detail();
		instructor_Detail.setDesignation("Lead");
		instructor_Detail.setYoutubeChannel("dsdsahdhiasidsaijd");
		Instructor instructor=new Instructor();
		instructor.setName("Ram");
		instructor.setAddress("Hyderabad");
		instructor.setInstructor_Detail(instructor_Detail);
		instructorRepository.save(instructor);*/
		//List<Instructor> instructors=instructorRepository.findAll();
		//Instructor instructor=instructorRepository.findById(1).get();
		//Instructor_Detail instructor_Detail=instructor.getInstructor_Detail();
		//System.out.println(instructor_Detail.getDesignation()+"\t"+instructor_Detail.getYoutubeChannel());
		//Instructor_Detail instructor_Detail=instructor_Detail_Repository.findById(1).get();
		
		Course c1=new Course();
		c1.setCourseName("java");
		c1.setDuration(100);
		c1.setFee(100000);
		Course c2=new Course();
		c2.setCourseName(".net");
		c2.setDuration(1000);
		c2.setFee(100);
		Instructor instructor=instructorRepository.findById(1).get();
		instructor.addCourse(c1);
		instructor.addCourse(c2);
		c1.setInstructor(instructor);
		c2.setInstructor(instructor);
		instructorRepository.save(instructor);
	}

}
