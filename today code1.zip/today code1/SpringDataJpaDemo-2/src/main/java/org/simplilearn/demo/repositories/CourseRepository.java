package org.simplilearn.demo.repositories;

import org.simplilearn.demo.entities.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Integer>{

}
