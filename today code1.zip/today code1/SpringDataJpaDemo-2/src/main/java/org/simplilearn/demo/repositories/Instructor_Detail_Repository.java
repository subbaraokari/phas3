package org.simplilearn.demo.repositories;

import org.simplilearn.demo.entities.Instructor_Detail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Instructor_Detail_Repository extends JpaRepository<Instructor_Detail, Integer>{

}
