package org.simplilearn.demo.repositories;

import org.simplilearn.demo.entities.Instructor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstructorRepository extends JpaRepository<Instructor, Integer>{

}
