package org.simplilearn.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaDemo3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaDemo3Application.class, args);
	}

}
