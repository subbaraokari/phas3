package org.simplilearn.demo;

import java.util.List;

import org.simplilearn.demo.entities.Product;
import org.simplilearn.demo.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MyRunner implements CommandLineRunner{
	@Autowired
	private ProductRepository productRepository;
	@Override
	public void run(String... args) throws Exception {
		/*Product product1=new Product();
		product1.setName("Camera");
		product1.setActive(true);
		product1.setPrice(200);
		productRepository.save(product1);
		Product product2=new Product();
		product2.setName("Laptop");
		product2.setActive(true);
		product2.setPrice(500);
		productRepository.save(product2);
		Product product3=new Product();
		product3.setName("Mouse");
		product3.setActive(true);
		product3.setPrice(50);
		productRepository.save(product3);*/
		Product product=productRepository.getPro("Camera");
		System.out.println(product.getName()+"\t"+product.getPrice());
		
		List<Product> products=productRepository.findByPriceLessThan(250);
		for(Product product2:products)
			System.out.println(product2.getName()+"\t"+product2.getPrice());
	}

}
