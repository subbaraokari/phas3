package org.simplilearn.demo.repositories;

import java.util.List;

import org.simplilearn.demo.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ProductRepository extends JpaRepository<Product, Integer>{
	
	Product findByName(String name);
	//select p from org.simplilearn.demo.entities.Product p where p.name=?
	List<Product> findByNameAndPrice(String name,int price);
	//select p from org.simplilearn.demo.entities.Product p where p.name=? and p.price=?
	List<Product> findByPriceLessThan(int price);
	//select p from org.simplilearn.demo.entities.Product p where p.price<?;
	List<Product> findByPriceBetween(int price1,int price2);
	@Query("select p from org.simplilearn.demo.entities.Product p where p.name=?1")
	Product productWithName(String name);
	//select p from org.simplilearn.demo.entities.Product p where p.price between price1 and price2;
	//@Query(value = "select p from org.simplilearn.demo.entities.Product p where p.name=?1")
	Product getProByName(String name);
	@Query(value = "select * from products p where p.price between ?1 and ?2",nativeQuery = true)
	List<Product> getProductsByPriceBetween(int price1,int price2);
}
