package org.simplilearn.demo.services;

import java.util.List;

import org.simplilearn.demo.entities.Emp;
import org.simplilearn.demo.repositories.EmpRepository;
import org.springframework.stereotype.Service;

@Service("empService")
public class EmpServiceImpl implements EmpService {
	private EmpRepository empRepository;
	
	public EmpServiceImpl(EmpRepository empRepository) {
		super();
		this.empRepository = empRepository;
	}

	@Override
	public void insertEmployee(Emp e) {
		empRepository.save(e);
	}

	@Override
	public void deleteEmployee(int eno) {
		empRepository.deleteById(eno);
	}

	@Override
	public void updateEmployee(int eno, Emp e) {
		Emp emp=empRepository.findById(eno).get();
		emp.setName(e.getName());
		emp.setAddress(e.getAddress());
		empRepository.save(emp);
	}

	@Override
	public List<Emp> getEmployees() {

		return empRepository.findAll();
	}

}
