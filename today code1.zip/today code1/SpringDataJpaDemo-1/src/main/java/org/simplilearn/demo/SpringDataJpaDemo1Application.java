package org.simplilearn.demo;

import java.util.List;

import org.simplilearn.demo.entities.Emp;
import org.simplilearn.demo.services.EmpService;
import org.simplilearn.demo.services.EmpServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringDataJpaDemo1Application {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(SpringDataJpaDemo1Application.class, args);
		EmpService service=context.getBean("empService", EmpServiceImpl.class);
		//service.insertEmployee(new Emp("suresh", "Chennai"));
		//service.insertEmployee(new Emp("Ramana", "Hyd"));
		//service.insertEmployee(new Emp("Arjun", "Chennai"));
		List<Emp> employees=service.getEmployees();
		for(Emp emp:employees) {
			System.out.println(emp.getEno()+"\t"+emp.getName()+"\t"+emp.getAddress());
		}
	}

}
