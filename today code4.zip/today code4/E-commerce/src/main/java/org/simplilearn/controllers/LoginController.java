package org.simplilearn.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.simplilearn.entities.Product;
import org.simplilearn.entities.User;
import org.simplilearn.services.ProductService;
import org.simplilearn.services.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/login")
public class LoginController {
	private UserService userService;
	private ProductService productService;
	
	public LoginController(UserService userService, ProductService productService) {
		super();
		this.userService = userService;
		this.productService = productService;
	}
	@RequestMapping("/show")
	public String showLogin() {
		return "login";
	}
	@RequestMapping("/process")
	public String process(HttpSession session,@RequestParam("username") String username,@RequestParam("password") String password,Model model) {
		String viewName="";
		User user=userService.validate(username, password);
		if(user!=null)
		{
			session.setAttribute("user", user);
			if(user.getUserType().equals("customer")) {
				List<Product> products=productService.getProducts();
				model.addAttribute("products", products);
				viewName="customerDashboard";
			}
				
			if(user.getUserType().equals("admin"))
				viewName="adminDashBoard";
		}
		else
		{
			model.addAttribute("msg", "Username or Password is wrong");
			viewName="login";
		}
		return viewName;
	}
}
