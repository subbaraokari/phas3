package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Product;

public interface ProductService {
	void addProduct(Product product);
	void deleteProduct(int pid);
	List<Product> getProducts();
	Product getProduct(int pid);
}
