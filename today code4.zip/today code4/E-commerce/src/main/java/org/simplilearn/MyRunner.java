package org.simplilearn;

import javax.transaction.Transactional;

import org.simplilearn.entities.Product;
import org.simplilearn.entities.User;
import org.simplilearn.repositories.ProductRepository;
import org.simplilearn.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

//@Component
public class MyRunner implements CommandLineRunner {
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private UserRepository userRepository;
	@Transactional
	@Override
	public void run(String... args) throws Exception {
		Product p1=new Product();
		p1.setName("Laptop");
		p1.setDescription("dsjdhashdisahdihsajd sdhuhdsahd");
		p1.setPrice(200);
		p1.setImageUrl("https://plus.unsplash.com/premium_photo-1681666713728-9ed75e148617?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8bGFwdG9wfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60");
		User user=userRepository.findById(2).get();
		user.addProduct(p1);
		p1.setUser(user);
		Product p2=new Product();
		p2.setName("Camera");
		p2.setDescription("dsjdhashdisahdihsajd sdhuhdsahd");
		p2.setPrice(100);
		p2.setImageUrl("https://plus.unsplash.com/premium_photo-1664701474595-741c871a107d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8Y2FtZXJhfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60");
		user.addProduct(p2);
		p2.setUser(user);
		userRepository.save(user);
	}

}
