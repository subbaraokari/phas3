package org.simplilearn.services;

import org.simplilearn.entities.User;

public interface UserService {
	void registerUser(User user);
	User validate(String username,String password);
}
