package org.simplilearn.controllers;

import javax.servlet.http.HttpServletRequest;

import org.simplilearn.entities.User;
import org.simplilearn.services.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/register")
public class RegistrationController {
	private UserService userService;

	public RegistrationController(UserService userService) {
		super();
		this.userService = userService;
	}
	@RequestMapping("/show")
	public String showRegistrationform() {
		return "register";
	}
	@RequestMapping(value = "/process",method = RequestMethod.POST)
	public String processRegister(HttpServletRequest req) {
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		User user=new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setUserType("customer");
		user.setActive("active");
		userService.registerUser(user);
		return "home";
	}
}
