package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Emp;
import org.simplilearn.repositories.EmpRepository;
import org.springframework.stereotype.Service;

@Service
public class EmpServiceImpl implements EmpService{
	private EmpRepository empRepository;
	
	
	public EmpServiceImpl(EmpRepository empRepository) {
		super();
		this.empRepository = empRepository;
	}

	@Override
	public void insertEmployee(Emp e) {
		empRepository.save(e);
	}

	@Override
	public void deleteEmployee(int eno) {
		empRepository.deleteById(eno);
	}

	@Override
	public List<Emp> getEmployees() {
		return empRepository.findAll();
	}

	@Override
	public Emp getEmployee(int eno) {
		return empRepository.findById(eno).get();
	}
}
