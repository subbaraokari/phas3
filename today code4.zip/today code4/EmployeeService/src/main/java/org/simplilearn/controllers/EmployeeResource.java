package org.simplilearn.controllers;

import java.util.List;

import org.simplilearn.entities.Emp;
import org.simplilearn.services.EmpService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController //=@Controller and @ResponseBody
@RequestMapping("/api/employees")
public class EmployeeResource {
	private EmpService employeeService;
	
	public EmployeeResource(EmpService employeeService) {
		super();
		this.employeeService = employeeService;
	}


	@GetMapping
	public ResponseEntity<List<Emp>> getEmployees(){
		List<Emp> employees=employeeService.getEmployees();
		return new ResponseEntity<List<Emp>>(employees, HttpStatus.OK);
	}
	@PostMapping
	public ResponseEntity<?> insertEmployee(@RequestBody Emp e){
		employeeService.insertEmployee(e);
		return new ResponseEntity<String>("Inserted Successfully", HttpStatus.CREATED);
	}
	@DeleteMapping("/delete/{eno}")
	public ResponseEntity<?> deleteEmployee(@PathVariable("eno") int eno){
		employeeService.deleteEmployee(eno);
		return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
	}
	@GetMapping("/{eno}")
	public ResponseEntity<Emp> getEmployee(@PathVariable("eno") int eno){
		Emp e=employeeService.getEmployee(eno);
		return new ResponseEntity<Emp>(e, HttpStatus.OK);
	}
}
