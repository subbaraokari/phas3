package org.simplilearn;

import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Quiz quiz=context.getBean("quiz", Quiz.class);
		System.out.println("The question is");
		System.out.println(quiz.getQuestion());
		Map<String, String> answers=quiz.getAnswers();
		Set<Map.Entry<String, String>> entries=answers.entrySet();
		System.out.println("The answers are");
		for(Map.Entry<String, String> entry:entries) {
			System.out.println(entry.getKey()+"\t"+entry.getValue());
		}
	}

}
