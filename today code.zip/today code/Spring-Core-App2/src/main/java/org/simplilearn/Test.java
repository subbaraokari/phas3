package org.simplilearn;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Emp emp=context.getBean("e", Emp.class);
		System.out.println(emp.getEno()+"\t"+emp.getName());
		Address address=emp.getAddress();
		System.out.println(address.getDno()+"\t"+address.getStreetName()+"\t"+address.getLoc());
		Company company=emp.getCompany();
		System.out.println(company.getCid()+"\t"+company.getCname()+"\t"+company.getDesignation());
	}

}
