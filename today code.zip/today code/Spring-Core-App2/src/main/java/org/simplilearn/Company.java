package org.simplilearn;

public class Company {
	private int cid;
	private String cname;
	private String designation;
	public Company() {
		// TODO Auto-generated constructor stub
	}
	public Company(int cid, String cname, String designation) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.designation = designation;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	

}
