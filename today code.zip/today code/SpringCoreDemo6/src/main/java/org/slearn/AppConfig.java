package org.slearn;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean(name = "e")
	public Emp emp() {
		Emp e=new Emp();
		e.setEno(1);
		e.setName("suresh");
		e.setAddress("Chennai");
		return e;
	}
}
