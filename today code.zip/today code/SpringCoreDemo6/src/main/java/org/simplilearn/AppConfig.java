package org.simplilearn;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean
	public Address address() {
		Address address=new Address();
		address.setDno(101);
		address.setStreetName("Gandhi");
		address.setLoc("Chennai");
		return address;
	}
	@Bean
	public Company company() {
		Company company=new Company();
		company.setCompanyName("Simplilearn");
		company.setLoc("Bangalore");
		return company;
	}
	@Bean
	public Emp emp() {
		Emp e=new Emp();
		e.setEno(1);
		e.setName("Suresh");
		e.setAddress(address());
		e.setCompany(company());
		return e;
	}
}
