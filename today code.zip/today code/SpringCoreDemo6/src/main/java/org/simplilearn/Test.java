package org.simplilearn;

import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig1.class);
		College college=context.getBean("college", College.class);
		System.out.println("The college name is "+college.getCollegeName());
		System.out.println("The courses are");
		Set<Course> courses=college.getCourses();
		for(Course course:courses) {
			System.out.println(course.getCid()+"\t"+course.getCname()+"\t"+course.getFee());
		}
	}

}
