package org.simplilearn;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig1 {
	
	public Course course1() {
		Course c1=new Course();
		c1.setCid(1);
		c1.setCname("Java");
		c1.setFee(10000);
		return c1;
	}
	public Course course2() {
		Course c2=new Course();
		c2.setCid(2);
		c2.setCname(".net");
		c2.setFee(20000);
		return c2;
	}
	public Course course3() {
		Course c3=new Course();
		c3.setCid(3);
		c3.setCname("python");
		c3.setFee(30000);
		return c3;
	}
	@Bean
	public Set<Course> courses(){
		Set<Course> courses=new HashSet<>();
		courses.add(course1());
		courses.add(course2());
		courses.add(course3());
		return courses;
	}
	@Bean
	public College college() {
		College college=new College();
		college.setCollegeName("Simplilearn");
		college.setCourses(courses());
		return college;
	}
}
