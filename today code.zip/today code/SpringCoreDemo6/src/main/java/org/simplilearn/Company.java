package org.simplilearn;

public class Company {
	private String companyName;
	private String loc;
	public Company() {
		// TODO Auto-generated constructor stub
	}
	public Company(String companyName, String loc) {
		super();
		this.companyName = companyName;
		this.loc = loc;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
}
