package org.simplilearn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("service")
public class Service {
	private Dao dao;
	public Service() {
	}
	@Autowired
	public Service(Dao dao) {
		super();
		System.out.println("Service class contructor");
		this.dao = dao;
	}
	public Dao getDao() {
		return dao;
	}
	
	
	public void setDao(Dao dao1) {
		System.out.println("service setter method");
		this.dao = dao1;
	}
	public void service() {
		dao.dao();
	}
}
