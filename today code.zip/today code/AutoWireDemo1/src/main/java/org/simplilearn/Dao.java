package org.simplilearn;

import org.springframework.stereotype.Component;

@Component("dao")
public class Dao {
	public void dao() {
		System.out.println("dao method");
	}
}
