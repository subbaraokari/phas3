package org.simplilearn.demo.config;

import org.simplilearn.demo.entities.Emp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean(name = "e")
	public Emp emp() {
		Emp e=new Emp(1, "suresh","Chennai");
		return e;
	}
}
