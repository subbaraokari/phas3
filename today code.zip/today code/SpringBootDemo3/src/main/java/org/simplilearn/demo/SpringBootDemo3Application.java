package org.simplilearn.demo;

import org.simplilearn.demo.entities.Emp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringBootDemo3Application {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(SpringBootDemo3Application.class, args);
		Emp e=context.getBean("e", Emp.class);
		System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
	}
}
