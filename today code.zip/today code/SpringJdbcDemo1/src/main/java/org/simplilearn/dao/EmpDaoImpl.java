package org.simplilearn.dao;

import java.util.List;

import org.simplilearn.entities.Emp;
import org.simplilearn.util.EmpPreparedStatementCreator;
import org.simplilearn.util.EmpPreparedStatementSetter;
import org.simplilearn.util.EmpResultSetExtractor;
import org.simplilearn.util.EmpRowMapper;
import org.simplilearn.util.MyPreparedStatementCreator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component("dao")
public class EmpDaoImpl implements EmpDao{
	private JdbcTemplate template;
	
	@Autowired
	public EmpDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}

	@Override
	public void insert(Emp e) {
		template.update("insert into emp values(?,?,?)", e.getEno(),e.getName(),e.getAddress());
		//template.update(new EmpPreparedStatementCreator(e));
		//template.update("insert into emp values(?,?,?)", new EmpPreparedStatementSetter(e));
	}

	@Override
	public void delete(int eno) {
		template.update("delete from emp where eno=?", eno);
	}

	@Override
	public void update(int eno, Emp e) {
		template.update("update emp set name=?,address=? where eno=?", e.getName(),e.getAddress(),e.getEno());
	}

	@Override
	public List<Emp> getAll() {
	
		List<Emp> employees=template.query("select * from emp", new EmpRowMapper());
		return employees;
	}
	@Override
	public Emp get(int eno) {
		Emp e=template.query(new MyPreparedStatementCreator(eno),new EmpResultSetExtractor());
		return e;
	}

}
