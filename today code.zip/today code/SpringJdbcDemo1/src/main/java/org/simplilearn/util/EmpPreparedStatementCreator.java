package org.simplilearn.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.simplilearn.entities.Emp;
import org.springframework.jdbc.core.PreparedStatementCreator;

public class EmpPreparedStatementCreator implements PreparedStatementCreator{
	private Emp e;
	
	public EmpPreparedStatementCreator(Emp e) {
		super();
		this.e = e;
	}

	@Override
	public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
		PreparedStatement pst=con.prepareStatement("insert into emp values(?,?,?)");
		pst.setInt(1, e.getEno());
		pst.setString(2, e.getName());
		pst.setString(3, e.getAddress());
		return pst;
	}
}
