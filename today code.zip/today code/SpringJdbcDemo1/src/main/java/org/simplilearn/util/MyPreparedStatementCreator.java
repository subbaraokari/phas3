package org.simplilearn.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementCreator;

public class MyPreparedStatementCreator implements PreparedStatementCreator{
	private int eno;
	public MyPreparedStatementCreator(int eno) {
		super();
		this.eno = eno;
	}

	@Override
	public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
		PreparedStatement pst=con.prepareStatement("select * from emp where eno=?");
		pst.setInt(1, eno);
		return pst;
	}

}
