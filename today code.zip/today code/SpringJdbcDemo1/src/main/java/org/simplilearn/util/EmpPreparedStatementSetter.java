package org.simplilearn.util;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.simplilearn.entities.Emp;
import org.springframework.jdbc.core.PreparedStatementSetter;

public class EmpPreparedStatementSetter implements PreparedStatementSetter{
	private Emp e;
	
	public EmpPreparedStatementSetter(Emp e) {
		super();
		this.e = e;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setInt(1, e.getEno());
		ps.setString(2, e.getName());
		ps.setString(3, e.getAddress());
	}

}
