package org.simplilearn.recipeapi.services;

import java.util.List;

import org.simplilearn.recipeapi.entities.Recipe;

public interface RecipeService {
	List<Recipe> getRecipes();
	void addRecipe(Recipe recipe);
	void deleteRecipe(int id);
	Recipe getRecipe(int id);
}
