package org.simplilearn.recipeapi.services;

import java.util.List;

import org.simplilearn.recipeapi.entities.Recipe;
import org.simplilearn.recipeapi.repositories.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RecipeServiceImpl implements RecipeService{
	@Autowired
	private RecipeRepository recipeRepository;
	@Override
	public List<Recipe> getRecipes() {
		return recipeRepository.findAll();
	}

	@Override
	public void addRecipe(Recipe recipe) {
		recipeRepository.save(recipe);
	}

	@Override
	public void deleteRecipe(int id) {
		recipeRepository.deleteById(id);
	}

	@Override
	public Recipe getRecipe(int id) {
		return recipeRepository.findById(id).get();
	}

}
