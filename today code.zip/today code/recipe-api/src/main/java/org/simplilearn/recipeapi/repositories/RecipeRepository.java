package org.simplilearn.recipeapi.repositories;

import org.simplilearn.recipeapi.entities.Recipe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecipeRepository extends JpaRepository<Recipe, Integer>{

}
