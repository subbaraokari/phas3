package org.simplilearn.demo.dao;

import java.util.List;

import org.simplilearn.demo.entities.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component("dao")
public class EmpDaoImpl implements EmpDao{
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public EmpDaoImpl(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void insert(Emp e) {
		jdbcTemplate.update("insert into emp values(?,?,?)", e.getEno(),e.getName(),e.getAddress());
	}

	@Override
	public void delete(int eno) {
		jdbcTemplate.update("delete from emp where eno=?", eno);
	}

	@Override
	public List<Emp> getAll() {
		
		return null;
	}

	@Override
	public Emp get(int eno) {
		// TODO Auto-generated method stub
		return null;
	}

}
