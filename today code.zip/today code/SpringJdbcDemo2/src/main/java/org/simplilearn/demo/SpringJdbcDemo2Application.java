package org.simplilearn.demo;

import org.simplilearn.demo.dao.EmpDao;
import org.simplilearn.demo.dao.EmpDaoImpl;
import org.simplilearn.demo.entities.Emp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringJdbcDemo2Application {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(SpringJdbcDemo2Application.class, args);
		EmpDao dao=context.getBean("dao", EmpDaoImpl.class);
		dao.insert(new Emp(3, "Raman", "Hyd"));
	}

}
