package org.simplilearn.demo.dao;

import java.util.List;

import org.simplilearn.demo.entities.Emp;

public interface EmpDao {
	void insert(Emp e);
	void delete(int eno);
	List<Emp> getAll();
	Emp get(int eno);
}
