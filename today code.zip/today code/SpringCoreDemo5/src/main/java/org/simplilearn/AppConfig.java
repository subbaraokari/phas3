package org.simplilearn;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean(name = "address")
	public Address address() {
		Address address=new Address();
		address.setDno(101);
		address.setStreetName("Gandhi Street");
		address.setLoc("Chennai");
		return address;
	}
	@Bean(name = "company")
	public Company company() {
		Company company=new Company();
		company.setCid(1);
		company.setCname("simplilearn");
		company.setDesignation("consultant");
		return company;
	}
	@Bean(name = "emp")
	public Emp emp() {
		Emp e=new Emp();
		e.setEno(1);
		e.setName("suresh");
		e.setAddress(address());
		e.setCompany(company());
		return e;
		
	}
}
