package org.simplilearn;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		College college=context.getBean("college", College.class);
		System.out.println("The college name is "+college.getCollegeName());
		System.out.println("The offered courses are");
		List<Course> courses=college.getCourses();
		for(Course course:courses) {
			System.out.println(course.getCid()+"\t"+course.getCname()+"\t"+course.getFee());
		}
	}

}
