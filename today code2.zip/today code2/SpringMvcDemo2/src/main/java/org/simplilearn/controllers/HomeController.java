package org.simplilearn.controllers;

import org.simplilearn.entities.Emp;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	/*@RequestMapping("/")
	public String showHome(Model model) {
		Emp e=new Emp(1, "suresh", "Chennai");
		model.addAttribute("emp", e);
		return "home";
	}*/
	/*@RequestMapping("/")
	public ModelAndView showHome() {
		Emp e=new Emp(1, "suresh", "Chennai");
		ModelAndView mv=new ModelAndView("home");
		mv.addObject("emp", e);
		return mv;
	}*/
	@RequestMapping("/")
	public String showHome(ModelMap map) {
		Emp e=new Emp(1, "suresh", "Chennai");
		map.put("emp", e);
		return "home";
	}
	
}
