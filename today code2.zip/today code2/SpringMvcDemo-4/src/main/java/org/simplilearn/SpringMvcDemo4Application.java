package org.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class SpringMvcDemo4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcDemo4Application.class, args);
	}

}
