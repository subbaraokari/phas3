package org.simplilearn.controllers;

import java.util.List;

import org.simplilearn.entities.Emp;
import org.simplilearn.services.EmployeeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmployeeController {
	private EmployeeService empService;
	
	public EmployeeController(EmployeeService empService) {
		super();
		this.empService = empService;
	}

	@RequestMapping("/abc")
	public String showHome(Model model) {
		List<Emp> employees=empService.getEmployees();
		model.addAttribute("emps", employees);
		return "home";
	}
}
